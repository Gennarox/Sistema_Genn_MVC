/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.cliente;
import Modelo.metodos;
import Modelo.producto;
import Modelo.proveedor;
import Modelo.usuario;
import Modelo.venta;
import Vista.CRUD_Cliente;
import Vista.CRUD_Producto;
import Vista.CRUD_Proveedor;
import Vista.Login;
import Vista.Menu_Principal;
import Vista.Registro;
import Vista.Vista_Venta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author HUAWEI
 */
public class controlador implements ActionListener {
    //METODOS   
    metodos met=new metodos();
    
    //USUARIO,LOGIN Y REGISTROS 
    usuario user=new usuario();
    Login log=new Login();
    Registro reg=new Registro();
    
    //MENU PRINCIPAL 
    Menu_Principal m_pri=new Menu_Principal();
    
    //CLIENTE
    cliente cli=new cliente();
    CRUD_Cliente cr_cli=new CRUD_Cliente();
    
    //PROVEEDOR
    proveedor pro=new proveedor();
    CRUD_Proveedor cr_pro=new CRUD_Proveedor();
    
    //PRODUCTO
    producto prod=new producto();
    CRUD_Producto cr_prod=new CRUD_Producto();
    
    //VENTA
    venta ven=new venta();
    Vista_Venta v_ven=new Vista_Venta();
    
     //--------------------------------------------CONSTRUCTOR--------------------------------------------//
    
    public controlador(Login log,Registro reg,usuario user,cliente cli,CRUD_Cliente cr_cli,Menu_Principal m_pri,proveedor pro,CRUD_Proveedor cr_pro,producto prod,CRUD_Producto cr_prod, venta ven, Vista_Venta v_ven){
    this.log=log;
    this.reg=reg;
    this.user=user;
    this.cli=cli;
    this.cr_cli=cr_cli;
    this.m_pri=m_pri;
    this.pro=pro;
    this.cr_pro=cr_pro;
    this.prod=prod;
    this.cr_prod=cr_prod;
    this.ven=ven;
    this.v_ven=v_ven;
    
    //registro de usuarios
    this.reg.btnRegistrar.addActionListener(this);
    this.reg.btnVolver.addActionListener(this);
    
    //login de usuarios
    this.log.btnIngresar.addActionListener(this);
    this.log.btnRegistrar.addActionListener(this);
    
    //menu principal
    this.m_pri.btnClientes.addActionListener(this);
    this.m_pri.btnProveedores.addActionListener(this);
    this.m_pri.btnProductos.addActionListener(this);
    this.m_pri.btnVentas.addActionListener(this);
    
    this.m_pri.mCerrarSesion.addActionListener(this);
    this.m_pri.mRegistrarUsuario.addActionListener(this);
    this.m_pri.mSalir.addActionListener(this);
    this.m_pri.mDescripcion.addActionListener(this);
    
    
    //CRUD Clientes
    this.cr_cli.btnInsertar.addActionListener(this);
    this.cr_cli.btnBuscar.addActionListener(this);
    this.cr_cli.btnEliminar.addActionListener(this);
    this.cr_cli.btnModificar.addActionListener(this);
    this.cr_cli.btnVolver.addActionListener(this);
    
    //CRUD Proveedor
    this.cr_pro.btnInsertar.addActionListener(this);
    this.cr_pro.btnBuscar.addActionListener(this);
    this.cr_pro.btnEliminar.addActionListener(this);
    this.cr_pro.btnModificar.addActionListener(this);
    this.cr_pro.btnVolver.addActionListener(this);
    
    //CRUD Producto
    this.cr_prod.btnInsertar.addActionListener(this);
    this.cr_prod.btnBuscar.addActionListener(this);
    this.cr_prod.btnEliminar.addActionListener(this);
    this.cr_prod.btnModificar.addActionListener(this);
    this.cr_prod.btnVolver.addActionListener(this);
    
    //Vista Venta
    this.v_ven.btnVaciar.addActionListener(this);
    this.v_ven.btnVolver.addActionListener(this);
    this.v_ven.btnCalcular.addActionListener(this);
    this.v_ven.btnCargar.addActionListener(this);
    this.v_ven.btnClientes.addActionListener(this);
    this.v_ven.btnProductos.addActionListener(this);
    }
    
    //--------------------------------------------METODOS--------------------------------------------//
    //LOGIN AL SISTEMA
    public void Ingresar(){
    
        String us=log.tUsuario.getText();
        String pw=log.tContraseña.getText();
    
        if(met.Autenticacion(us,pw)){
        
//        reg.setVisible(true);
        log.setVisible(false);
        m_pri.setVisible(true);
        
//        JOptionPane.showMessageDialog(null, "Logueo exitoso");
        
        }else {
            JOptionPane.showMessageDialog(null, "Logueo fallido, usuario o contraseña incorrecta.");        
            log.tUsuario.setText("");
            log.tContraseña.setText("");}
    }    
    //REGISTRO DE USUARIOS EN EL SISTEMA
    public void Registrar(){
    
        user.setNombre(reg.tNombre.getText());
        user.setApellido(reg.tApellido.getText());
        user.setCorreo(reg.tCorreo.getText());
        user.setUsuario(reg.tUsuario.getText());
        user.setPass(reg.tContraseña.getText());
    
    if(met.InsertarUsuario(user)){
    
        reg.setVisible(false);
        log.setVisible(true);
        
    JOptionPane.showMessageDialog(null, "Usuario registrado");
    
    } else{JOptionPane.showMessageDialog(null, "Error al registrar nuevo usuario"); }
    
    }
    //CLIENTES
    public void Registrar_Cliente(){
        cli.setNombre(cr_cli.tNombre.getText());
        cli.setApellido(cr_cli.tApellido.getText());
        cli.setDni(cr_cli.tDni.getText());
        cli.setDireccion(cr_cli.tDireccion.getText());
        cli.setCorreo(cr_cli.tCorreo.getText());
        cli.setTelefono(cr_cli.tTelefono.getText());
        cli.setTipo(cr_cli.lisTipo.getText());
        cli.setSector(cr_cli.lisSector.getText());
        cli.setEstado(cr_cli.lisEstado.getText());
    
        if(met.InsertarCliente(cli)){
            JOptionPane.showMessageDialog(null, "Cliente Registrado");
        } else{
            JOptionPane.showMessageDialog(null, "Error al Registrar Cliente");
        }
    
    }
    public void Buscar_Cliente(){
        cli.setDni(cr_cli.tDni.getText());
        if(met.BuscarCliente(cli)){
            cr_cli.tNombre.setText(cli.getNombre());
            cr_cli.tApellido.setText(cli.getApellido());
            cr_cli.tDireccion.setText(cli.getDireccion());
            cr_cli.tCorreo.setText(cli.getCorreo());
            cr_cli.tTelefono.setText(cli.getTelefono());
            cr_cli.lisTipo.setText(cli.getTipo());
            cr_cli.lisSector.setText(cli.getSector());
            cr_cli.lisEstado.setText(cli.getEstado());
            
        } else{
            JOptionPane.showMessageDialog(null, "Error al buscar cliente");
        }
    
    }
    public void Modificar_Cliente(){
        cli.setDni(cr_cli.tDni.getText());
        cli.setNombre(cr_cli.tNombre.getText());
        cli.setApellido(cr_cli.tApellido.getText());
        cli.setDireccion(cr_cli.tDireccion.getText());
        cli.setCorreo(cr_cli.tCorreo.getText());
        cli.setTelefono(cr_cli.tTelefono.getText());
        cli.setTipo(cr_cli.lisTipo.getText());
        cli.setSector(cr_cli.lisSector.getText());
        cli.setEstado(cr_cli.lisEstado.getText());
        if(met.ModificarCliente(cli)){
            JOptionPane.showMessageDialog(null, "Cliente modificado exitosamente");
        } else{
            JOptionPane.showMessageDialog(null, "Error al modificar cliente");
        }
    }
    public void Eliminar_Cliente(){
        cli.setDni(cr_cli.tDni.getText());
        if(met.EliminarCliente(cli)){
            JOptionPane.showMessageDialog(null, "Cliente eliminado de la base de datos");
        } else{
            JOptionPane.showMessageDialog(null, "Error al eliminar cliente");
        }
    
    }
    //PROVEEDORES
    public void Registrar_Proveedor(){
        pro.setNombre(cr_pro.tNombre.getText());
        pro.setApellido(cr_pro.tApellido.getText());
        pro.setDni(cr_pro.tDni.getText());
        pro.setDireccion(cr_pro.tDireccion.getText());
        pro.setCorreo(cr_pro.tCorreo.getText());
        pro.setTelefono(cr_pro.tTelefono.getText());
        pro.setTipo(cr_pro.lisTipo.getText());
        pro.setSector(cr_pro.lisSector.getText());
        pro.setObservacion(cr_pro.tObs.getText());
    
        if(met.InsertarProveedor(pro)){
            JOptionPane.showMessageDialog(null, "Proveedor Registrado");
        } else{
            JOptionPane.showMessageDialog(null, "Error al Registrar Proveedor");
        }
    
    }
    public void Buscar_Proveedor(){
        pro.setDni(cr_pro.tDni.getText());
        if(met.BuscarProveedor(pro)){
            cr_pro.tNombre.setText(pro.getNombre());
            cr_pro.tApellido.setText(pro.getApellido());
            cr_pro.tDireccion.setText(pro.getDireccion());
            cr_pro.tCorreo.setText(pro.getCorreo());
            cr_pro.tTelefono.setText(pro.getTelefono());
            cr_pro.lisTipo.setText(pro.getTipo());
            cr_pro.lisSector.setText(pro.getSector());
            cr_pro.tObs.setText(pro.getObservacion());
            
        } else{
            JOptionPane.showMessageDialog(null, "Error al buscar Proveedor");
        }
    
    }
    public void Modificar_Proveedor(){
        pro.setDni(cr_pro.tDni.getText());
        pro.setNombre(cr_pro.tNombre.getText());
        pro.setApellido(cr_pro.tApellido.getText());
        pro.setDireccion(cr_pro.tDireccion.getText());
        pro.setCorreo(cr_pro.tCorreo.getText());
        pro.setTelefono(cr_pro.tTelefono.getText());
        pro.setTipo(cr_pro.lisTipo.getText());
        pro.setSector(cr_pro.lisSector.getText());
        pro.setObservacion(cr_pro.tObs.getText());
        if(met.ModificarProveedor(pro)){
            JOptionPane.showMessageDialog(null, "Proveedor modificado exitosamente");
        } else{
            JOptionPane.showMessageDialog(null, "Error al modificar Proveedor");
        }
    }
    public void Eliminar_Proveedor(){
        pro.setDni(cr_pro.tDni.getText());
        if(met.EliminarProveedor(pro)){
            JOptionPane.showMessageDialog(null, "Proveedor eliminado de la base de datos");
        } else{
            JOptionPane.showMessageDialog(null, "Error al eliminar Proveedor");
        }
    
    } 
    //PRODUCTOS
    public void Registrar_Producto(){
        prod.setId(Integer.parseInt(cr_prod.tId.getText()));
        prod.setDenominacion(cr_prod.tDenominacion.getText());
        prod.setTipo(cr_prod.tTipo.getText());
        prod.setPrecio_compra(Integer.parseInt(cr_prod.tPrecio_compra.getText()));
        prod.setPrecio_venta(Integer.parseInt(cr_prod.tPrecio_venta.getText()));
        prod.setObservacion(cr_prod.tObs.getText());
    
        if(met.InsertarProducto(prod)){
            JOptionPane.showMessageDialog(null, "Producto Registrado");
        } else{
            JOptionPane.showMessageDialog(null, "Error al Registrar Producto");
        }
    
    }
    public void Buscar_Producto(){
        prod.setId(Integer.parseInt(cr_prod.tId.getText()));
        if(met.BuscarProducto(prod)){
            cr_prod.tDenominacion.setText(prod.getDenominacion());
            cr_prod.tTipo.setText(prod.getTipo());
            cr_prod.tPrecio_compra.setText(Integer.toString(prod.getPrecio_compra()));
            cr_prod.tPrecio_venta.setText(Integer.toString(prod.getPrecio_venta()));
            cr_prod.tObs.setText(prod.getObservacion());
  
        } else{
            JOptionPane.showMessageDialog(null, "Error al buscar Producto");
        }
    
    }
    public void Modificar_Producto(){
        prod.setId(Integer.parseInt(cr_prod.tId.getText()));
        prod.setDenominacion(cr_prod.tDenominacion.getText());
        prod.setTipo(cr_prod.tTipo.getText());
        prod.setPrecio_compra(Integer.parseInt(cr_prod.tPrecio_compra.getText()));
        prod.setPrecio_venta(Integer.parseInt(cr_prod.tPrecio_venta.getText()));
        prod.setObservacion(cr_prod.tObs.getText());

        if(met.ModificarProducto(prod)){
            JOptionPane.showMessageDialog(null, "Producto modificado exitosamente");
        } else{
            JOptionPane.showMessageDialog(null, "Error al modificar Producto");
        }
    }
    public void Eliminar_Producto(){
        prod.setId(Integer.parseInt(cr_prod.tId.getText()));
        if(met.EliminarProducto(prod)){
            JOptionPane.showMessageDialog(null, "Producto eliminado de la base de datos");
        } else{
            JOptionPane.showMessageDialog(null, "Error al eliminar Producto");
        }
    
    } 
    //VENTAS
    public void Cargar_Venta(){
        ven.setDni_cliente(v_ven.tDni.getText());
        ven.setId_producto(Integer.parseInt(v_ven.tIdProducto.getText()));
        ven.setCantidad(Integer.parseInt(v_ven.tCantidad.getText()));
        ven.setTipo_pago((String) v_ven.lisTipoPago.getSelectedItem());
        ven.setTipo_venta((String) v_ven.lisTipoVenta.getSelectedItem());
        ven.setTotal_venta(Integer.parseInt(v_ven.tTotalVenta.getText()));
        if(met.CargarVenta(ven)){
            JOptionPane.showMessageDialog(null, "Venta Registrada");
        } else{
            JOptionPane.showMessageDialog(null, "Error al Registrar Venta");
        }  
    }
    public void Calcular_Venta(){
        cli.setDni(v_ven.tDni.getText());
        prod.setId(Integer.parseInt(v_ven.tIdProducto.getText()));
        if(met.BuscarCliente_Venta(cli)){
            v_ven.tCliente.setText(" Nombre: " + cli.getNombre()+ ", Apellido: " + cli.getApellido() + ", Telefono: " + cli.getTelefono() + ".");   
        } else{
            v_ven.tCliente.setText("Cliente no registrado");
        }
        if(met.BuscarProducto_Venta(prod)){
            v_ven.tProducto.setText(" Denominacion: " + prod.getDenominacion() + ", Tipo: " + prod.getTipo() + ", Precio venta: " + prod.getPrecio_venta() + "." );   
        } else{
            v_ven.tProducto.setText("Producto no registrado");
        }
        v_ven.tTotalVenta.setText(Integer.toString(prod.getPrecio_venta()*(Integer.parseInt(v_ven.tCantidad.getText()))));
    }
    //--------------------------------------------CONTROLADOR DE ACCIONES--------------------------------------------//
    
    @Override
    public void actionPerformed(ActionEvent e) {
        //REGISTRO
        if(e.getSource()== reg.btnRegistrar){
            Registrar();
        }
        if(e.getSource()== reg.btnVolver){
            log.setVisible(true);
            reg.setVisible(false); 
        }
        //LOGIN
        if(e.getSource()== log.btnIngresar){
            Ingresar();        
        }
        if(e.getSource()== log.btnRegistrar){
            reg.setVisible(true);  
            log.setVisible(false);
        }
        //MENU PRINCIPAL
        if(e.getSource()== m_pri.btnClientes){
            cr_cli.setVisible(true);
        }
        if(e.getSource()== m_pri.btnProveedores){
            cr_pro.setVisible(true);
        }
        if(e.getSource()== m_pri.btnProductos){
            cr_prod.setVisible(true);
        }
        if(e.getSource()== m_pri.btnVentas){
            v_ven.setVisible(true);
        }
        if(e.getSource()== m_pri.mCerrarSesion){
            m_pri.setVisible(false);
            log.setVisible(true);
        }
        if(e.getSource()== m_pri.mRegistrarUsuario){
            m_pri.setVisible(false);
            reg.setVisible(true);
        }
        if(e.getSource()== m_pri.mSalir){
            m_pri.setVisible(false);
        }        
        if(e.getSource()== m_pri.mSalir){
            m_pri.setVisible(false);
        } 
        if(e.getSource()== m_pri.mDescripcion){
            JOptionPane.showMessageDialog(null, "Proyecto - Examen Parcial 3 - Optativo II" + "\n\nDesarollado por: Iván Gennaro" + "\nFecha: Junio 2022");
        } 
        //CRUD_CLIENTE
        if(e.getSource()== cr_cli.btnInsertar){
            Registrar_Cliente();        
        }
        if(e.getSource()== cr_cli.btnBuscar){
            Buscar_Cliente();        
        }
        if(e.getSource()== cr_cli.btnEliminar){
            Eliminar_Cliente();        
        }      
        if(e.getSource()== cr_cli.btnModificar){
            Modificar_Cliente();        
        }   
        if(e.getSource()== cr_cli.btnVolver){
            m_pri.setVisible(true);
            cr_cli.setVisible(false); 
        }
        //CRUD_PROVEEDOR
        if(e.getSource()== cr_pro.btnInsertar){
            Registrar_Proveedor();        
        }
        if(e.getSource()== cr_pro.btnBuscar){
            Buscar_Proveedor();        
        }
        if(e.getSource()== cr_pro.btnEliminar){
            Eliminar_Proveedor();        
        }      
        if(e.getSource()== cr_pro.btnModificar){
            Modificar_Proveedor();        
        } 
        if(e.getSource()== cr_pro.btnVolver){
            m_pri.setVisible(true);
            cr_pro.setVisible(false); 
        }        
        //CRUD_PRODUCTO
        if(e.getSource()== cr_prod.btnInsertar){
            Registrar_Producto();        
        }
        if(e.getSource()== cr_prod.btnBuscar){
            Buscar_Producto();        
        }
        if(e.getSource()== cr_prod.btnModificar){
            Modificar_Producto();        
        }
        if(e.getSource()== cr_prod.btnEliminar){
            Eliminar_Producto();        
        }
        if(e.getSource()== cr_prod.btnVolver){
            m_pri.setVisible(true);
            cr_prod.setVisible(false); 
        }
        //VENTA
        if(e.getSource()== v_ven.btnCargar){
            Cargar_Venta();        
        }
        if(e.getSource()== v_ven.btnVolver){
            m_pri.setVisible(true);
            v_ven.setVisible(false); 
        }
        if(e.getSource()== v_ven.btnCalcular){
            Calcular_Venta();
        }
        if(e.getSource()== v_ven.btnClientes){
            cr_cli.setVisible(true);
            v_ven.setVisible(false);
        }
        if(e.getSource()== v_ven.btnProductos){
            cr_prod.setVisible(true);
            v_ven.setVisible(false);
        }             
    }   
}
