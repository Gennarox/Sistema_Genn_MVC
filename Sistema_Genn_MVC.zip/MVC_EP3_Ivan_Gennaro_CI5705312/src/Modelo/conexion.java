/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author HUAWEI
 */
public class conexion {
    public Connection con=null;
    
    public static Connection Conectar(){
        Connection cn=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mvc_bd_ep3_ivan_gennaro_ci5705312","root","Genn_5705312");
            
        }catch (ClassNotFoundException | SQLException e){
            System.out.println(String.valueOf(e));
        }
    return cn;
    }
    
}
