/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author HUAWEI
 */
public class metodos {
    
    //REGISTRO DE NUEVOS USUARIOS EN EL SISTEMA
    public static boolean InsertarUsuario(usuario x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    
    String sql="INSERT INTO USUARIO (NOMBRE,APELLIDO,CORREO,USER,PASS) VALUES (?,?,?,?,?)";
    
    try{
        ps=cn.prepareStatement(sql);
        ps.setString(1, x.getNombre());
        ps.setString(2, x.getApellido());
        ps.setString(3, x.getCorreo());
        ps.setString(4, x.getUsuario());
        ps.setString(5, x.getPass());
        ps.execute();
        cn.close();
    return true;    
   
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }
    //AUTENTICACION DE LOGIN
    public static boolean Autenticacion(String Puser, String Ppass){
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    ResultSet rs=null;
    
    String sql="SELECT USER, PASS FROM USUARIO WHERE USER=? AND PASS=?";
    try{
        ps=cn.prepareStatement(sql);
        ps.setString(1, Puser);
        ps.setString(2, Ppass);
        rs=ps.executeQuery();
        
        while(rs.next()){
            cn.close();
            return true;
        }
        
    }catch(Exception e){
        System.out.println(e);
    }  
            return false;
    }
    //CLIENTES
    public static boolean InsertarCliente(cliente x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    
    String sql="INSERT INTO CLIENTE (NOMBRE,APELLIDO,DNI,DIRECCION,CORREO,TELEFONO,TIPO,SECTOR,ESTADO) VALUES (?,?,?,?,?,?,?,?,?)";
    
    try{
        ps=cn.prepareStatement(sql);
        ps.setString(1, x.getNombre());
        ps.setString(2, x.getApellido());
        ps.setString(3, x.getDni());
        ps.setString(4, x.getDireccion());
        ps.setString(5, x.getCorreo());
        ps.setString(6, x.getTelefono());
        ps.setString(7, x.getTipo());
        ps.setString(8, x.getSector());
        ps.setString(9, x.getEstado());
        ps.execute();
        cn.close();
    return true;    
   
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }
    
    public static boolean BuscarCliente(cliente x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    ResultSet rs=null;

    String sql="SELECT * FROM CLIENTE WHERE DNI=?";
    
    try{
        ps = cn.prepareStatement(sql);
        ps.setString(1,x.getDni());
        rs=ps.executeQuery();
    if(rs.next()){
        x.setNombre(rs.getString("nombre"));
        x.setApellido(rs.getString("apellido"));
        x.setDireccion(rs.getString("direccion"));
        x.setCorreo(rs.getString("correo"));
        x.setTelefono(rs.getString("telefono"));
        x.setTipo(rs.getString("tipo"));
        x.setSector(rs.getString("sector"));
        x.setEstado(rs.getString("estado"));
        return true;
    } return false; 
    
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }
    
    public static boolean EliminarCliente(cliente x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;

    String sql="DELETE FROM CLIENTE WHERE DNI=?";
    
    try{
        ps = cn.prepareStatement(sql);
        ps.setString(1,x.getDni());
        ps.execute();
        return true;
    }
   
    catch(Exception e){
        System.out.println(e);
    }return false;
    }
    
    public static boolean ModificarCliente(cliente x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;

    String sql="UPDATE CLIENTE SET NOMBRE=?, APELLIDO=?, DIRECCION=?, CORREO=?, TELEFONO=?, TIPO=?, SECTOR=?, ESTADO=? WHERE DNI=?";
    
    try{
        ps = cn.prepareStatement(sql);

        ps.setString(1,x.getNombre());
        ps.setString(2,x.getApellido());
        ps.setString(3,x.getDireccion());
        ps.setString(4,x.getCorreo());
        ps.setString(5,x.getTelefono());
        ps.setString(6,x.getTipo());
        ps.setString(7,x.getSector());
        ps.setString(8,x.getEstado());
        ps.setString(9,x.getDni());
        ps.execute();
        return true;
    }
   
    catch(Exception e){
        System.out.println(e);
    }return false;
    }
    
    //PROVEEDORES
    public static boolean InsertarProveedor(proveedor x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    
    String sql="INSERT INTO PROVEEDOR (NOMBRE,APELLIDO,DNI,DIRECCION,CORREO,TELEFONO,TIPO,SECTOR,OBSERVACION) VALUES (?,?,?,?,?,?,?,?,?)";
    
    try{
        ps=cn.prepareStatement(sql);
        ps.setString(1, x.getNombre());
        ps.setString(2, x.getApellido());
        ps.setString(3, x.getDni());
        ps.setString(4, x.getDireccion());
        ps.setString(5, x.getCorreo());
        ps.setString(6, x.getTelefono());
        ps.setString(7, x.getTipo());
        ps.setString(8, x.getSector());
        ps.setString(9, x.getObservacion());
        ps.execute();
        cn.close();
    return true;    
   
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }
    
    public static boolean BuscarProveedor(proveedor x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    ResultSet rs=null;

    String sql="SELECT * FROM PROVEEDOR WHERE DNI=?";
    
    try{
        ps = cn.prepareStatement(sql);
        ps.setString(1,x.getDni());
        rs=ps.executeQuery();
    if(rs.next()){
        x.setNombre(rs.getString("nombre"));
        x.setApellido(rs.getString("apellido"));
        x.setDireccion(rs.getString("direccion"));
        x.setCorreo(rs.getString("correo"));
        x.setTelefono(rs.getString("telefono"));
        x.setTipo(rs.getString("tipo"));
        x.setSector(rs.getString("sector"));
        x.setObservacion(rs.getString("observacion"));
        return true;
    } return false; 
    
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }
    
    public static boolean EliminarProveedor(proveedor x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;

    String sql="DELETE FROM PROVEEDOR WHERE DNI=?";
    
    try{
        ps = cn.prepareStatement(sql);
        ps.setString(1,x.getDni());
        ps.execute();
        return true;
    }
   
    catch(Exception e){
        System.out.println(e);
    }return false;
    }
    
    public static boolean ModificarProveedor(proveedor x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;

    String sql="UPDATE PROVEEDOR SET NOMBRE=?, APELLIDO=?, DIRECCION=?, CORREO=?, TELEFONO=?, TIPO=?, SECTOR=?, OBSERVACION=? WHERE DNI=?";
    
    try{
        ps = cn.prepareStatement(sql);

        ps.setString(1,x.getNombre());
        ps.setString(2,x.getApellido());
        ps.setString(3,x.getDireccion());
        ps.setString(4,x.getCorreo());
        ps.setString(5,x.getTelefono());
        ps.setString(6,x.getTipo());
        ps.setString(7,x.getSector());
        ps.setString(8,x.getObservacion());
        ps.setString(9,x.getDni());
        ps.execute();
        return true;
    }
   
    catch(Exception e){
        System.out.println(e);
    }return false;
    }
    
    //PRODUCTOS
    public static boolean InsertarProducto(producto x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    
    String sql="INSERT INTO PRODUCTO (ID,DENOMINACION,TIPO,PRECIO_COMPRA,PRECIO_VENTA,OBSERVACION) VALUES (?,?,?,?,?,?)";
    
    try{
        ps=cn.prepareStatement(sql);
        ps.setInt(1, x.getId());
        ps.setString(2, x.getDenominacion());
        ps.setString(3, x.getTipo());
        ps.setInt(4, x.getPrecio_compra());
        ps.setInt(5, x.getPrecio_venta());
        ps.setString(6, x.getObservacion());
        ps.execute();
        cn.close();
    return true;    
   
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }

    public static boolean BuscarProducto(producto x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    ResultSet rs=null;

    String sql="SELECT * FROM PRODUCTO WHERE ID=?";
    
    try{
        ps = cn.prepareStatement(sql);
        ps.setInt(1,x.getId());
        rs=ps.executeQuery();
    if(rs.next()){
        x.setDenominacion(rs.getString("denominacion"));
        x.setTipo(rs.getString("tipo"));
        x.setPrecio_compra(rs.getInt("precio_compra"));
        x.setPrecio_venta(rs.getInt("precio_venta"));
        x.setObservacion(rs.getString("observacion"));
        return true;
    } return false; 
    
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }

    public static boolean EliminarProducto(producto x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;

    String sql="DELETE FROM PRODUCTO WHERE ID=?";
    
    try{
        ps = cn.prepareStatement(sql);
        ps.setInt(1,x.getId());
        ps.execute();
        return true;
    }
   
    catch(Exception e){
        System.out.println(e);
    }return false;
    }

    public static boolean ModificarProducto(producto x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;

    String sql="UPDATE PRODUCTO SET DENOMINACION=?, TIPO=?, PRECIO_COMPRA=?, PRECIO_VENTA=?, OBSERVACION=? WHERE ID=?";
    
    try{
        ps = cn.prepareStatement(sql);

        ps.setString(1,x.getDenominacion());
        ps.setString(2,x.getTipo());
        ps.setInt(3,x.getPrecio_compra());
        ps.setInt(4,x.getPrecio_venta());
        ps.setString(5,x.getObservacion());
        ps.setInt(6,x.getId());
        ps.execute();
        return true;
    }
   
    catch(Exception e){
        System.out.println(e);
    }return false;
    }  
    
    //VENTAS
    public static boolean CargarVenta(venta x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    
    String sql="INSERT INTO VENTA (DNI_CLIENTE,ID_PRODUCTO,CANTIDAD,TOTAL_VENTA,TIPO_PAGO,TIPO_VENTA) VALUES (?,?,?,?,?,?)";
    
    try{
        ps=cn.prepareStatement(sql);
        ps.setString(1, x.getDni_cliente());
        ps.setInt(2, x.getId_producto());
        ps.setInt(3, x.getCantidad());
        ps.setInt(4, x.getTotal_venta());
        ps.setString(5, x.getTipo_pago());
        ps.setString(6, x.getTipo_venta());
        
        ps.execute();
        cn.close();
    return true;    
   
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }

    public static boolean BuscarProducto_Venta(producto x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    ResultSet rs=null;

    String sql="SELECT * FROM PRODUCTO WHERE ID=?";
    
    try{
        ps = cn.prepareStatement(sql);
        ps.setInt(1,x.getId());
        rs=ps.executeQuery();
    if(rs.next()){
        x.setDenominacion(rs.getString("denominacion"));
        x.setTipo(rs.getString("tipo"));
        x.setPrecio_venta(rs.getInt("precio_venta"));
        return true;
    } return false; 
    
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }

    public static boolean BuscarCliente_Venta(cliente x){
    
    Connection cn=conexion.Conectar();
    PreparedStatement ps=null;
    ResultSet rs=null;

    String sql="SELECT * FROM CLIENTE WHERE DNI=?";
    
    try{
        ps = cn.prepareStatement(sql);
        ps.setString(1,x.getDni());
        rs=ps.executeQuery();
    if(rs.next()){
        x.setNombre(rs.getString("nombre"));
        x.setApellido(rs.getString("apellido"));
        x.setTelefono(rs.getString("telefono"));
        return true;
    } return false; 
    
    }catch(Exception e){
        System.out.println(e);
    }
    return false;
    }    
}
