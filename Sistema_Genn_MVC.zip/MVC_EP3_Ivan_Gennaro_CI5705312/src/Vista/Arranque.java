/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.controlador;
import Modelo.cliente;
import Modelo.metodos;
import Modelo.producto;
import Modelo.proveedor;
import Modelo.usuario;
import Modelo.venta;

/**
 *
 * @author HUAWEI
 */
public class Arranque {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //METODOS   
        metodos met=new metodos();

        //USUARIO,LOGIN Y REGISTROS 
        usuario user=new usuario();
        Login log=new Login();
        Registro reg=new Registro();

        //MENU PRINCIPAL 
        Menu_Principal m_pri=new Menu_Principal();

        //CLIENTE
        cliente cli=new cliente();
        CRUD_Cliente cr_cli=new CRUD_Cliente();

        //PROVEEDOR
        proveedor pro=new proveedor();
        CRUD_Proveedor cr_pro=new CRUD_Proveedor();

        //PRODUCTO
        producto prod=new producto();
        CRUD_Producto cr_prod=new CRUD_Producto();

        //VENTA
        venta ven=new venta();
        Vista_Venta v_ven=new Vista_Venta();

        controlador con = new controlador(log,reg,user,cli,cr_cli,m_pri,pro,cr_pro,prod,cr_prod,ven,v_ven);
        log.setVisible(true);
    }
    
}
